
# BLUM Crypto
BLUM CRYPTO

Register Here : [BlumCrypto](https://t.me/blum/app?startapp=ref_lHZLjPuq0F)


## Features
- Auto Clear Task
- Auto Farming
- Auto Join Tribe
- Auto Claim Ref
- Multi Account
- Check total balance all accounts

## Installation

Install with python

1. Download Python
2. Install Module 
3. Buka Bot Blum di PC
4. Jika sudah terbuka > Klik kanan Inspect
5. Di application storage > __telegram__initParams
6. Ambil tgwbappdata
